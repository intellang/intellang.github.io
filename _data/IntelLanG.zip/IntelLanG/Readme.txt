Please, before compiling, download and uncompress the file anthology.bib from
https://aclweb.org/anthology/anthology.bib.gz